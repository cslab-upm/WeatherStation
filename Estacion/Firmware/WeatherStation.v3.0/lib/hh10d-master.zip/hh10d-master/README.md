# hh10d
Humidity Sensor Arduino Library for this module:
www.hoperf.com/upload/sensor/hh10d.pdf

Dependencies:

1. Wire: Comes with Arduino IDE

2. FreqCount: https://github.com/PaulStoffregen/FreqCount
